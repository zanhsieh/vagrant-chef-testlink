<?php /* Smarty version 2.6.26, created on 2011-03-19 09:05:26
         compiled from error_icon.tpl */ ?>
<img id="error_icon_<?php echo $this->_tpl_vars['field']; ?>
" style="visibility: hidden;" 
     src="<?php echo @TL_THEME_IMG_DIR; ?>
/error.gif" alt="error condition detected" 
     title="error condition detected" width="1" height="1" />