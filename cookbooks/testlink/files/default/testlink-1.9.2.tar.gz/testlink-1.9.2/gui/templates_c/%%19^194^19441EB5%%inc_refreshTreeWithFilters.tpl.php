<?php /* Smarty version 2.6.26, created on 2011-03-19 09:06:19
         compiled from inc_refreshTreeWithFilters.tpl */ ?>

<?php echo '
<script type="text/javascript">
	parent.frames[\'treeframe\'].document.forms[\'filter_panel_form\'].submit();
</script>
'; ?>
