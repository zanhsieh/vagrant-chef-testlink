<?php $_config_vars = array (
  'REQ_DOCID_SIZE' => '35',
  'REQ_DOCID_MAXLEN' => '64',
  'REQSPEC_DOCID_SIZE' => '35',
  'REQSPEC_DOCID_MAXLEN' => '64',
  'TC_ID_SIZE' => '12',
  'TC_ID_MAXLEN' => '30',
  'STEP_NUMBER_SIZE' => '1',
  'STEP_NUMBER_MAXLEN' => '2',
  'SCOPE_TRUNCATE' => '100',
  'SCOPE_SHORT_TRUNCATE' => '30',
  'FILENAME_MAXLEN' => '50',
  'FILENAME_SIZE' => '50',
); ?>