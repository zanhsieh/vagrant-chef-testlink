/* 
$Revision: 1.2 $
$Date: 2007/10/19 06:53:06 $
$Author: franciscom $
$Name:  $
*/
ALTER TABLE `tcversions` CHANGE COLUMN `open` `is_open` TINYINT(1) NOT NULL DEFAULT 1;