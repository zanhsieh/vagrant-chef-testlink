/* 
$File:$
$Revision: 1.2 $
$Date: 2007/10/21 15:59:50 $
$Author: franciscom $
$Name:  $
*/
ALTER TABLE builds RENAME open TO is_open;