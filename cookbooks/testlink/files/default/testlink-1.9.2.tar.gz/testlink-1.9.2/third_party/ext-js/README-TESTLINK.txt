/**
 * TestLink Open Source Project - http://testlink.sourceforge.net/ 
 * This script is distributed under the GNU General Public License 2 or later. 
 *
 * Filename $RCSfile: README-TESTLINK.txt,v $
 *
 * @version $Revision: 1.1 $
 * @modified $Date: 2010/08/20 17:16:54 $ by $Author: franciscom $
 *
 *-----------------------------------------------------------------------------
*/

Folder structure remapped for TestLink

Ext-js Distribution   -   TestLink
resources             -   all contents copied under third_party\ext-js\ 
examples\ux           -   some interesting files copied unders third_party\ext-js\ux 